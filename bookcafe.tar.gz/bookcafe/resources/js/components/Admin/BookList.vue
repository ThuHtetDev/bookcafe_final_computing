<template>
<div class="container">
  <main class="grid">
    <div v-for="(book,index) in booklists" :key="index">
    <article>
     <img class="img-fluid fit-image" v-bind:src="'/storage/user_'+book.user_id+'/book/front_cover/'+book.front_cover">
      <div class="text">
        <h3 style="height: 50px; font-size: 20px;">
          {{book.name}}
        </h3>
        <span v-if="book.rentList.length > 0" class="right badge badge-warning">
            {{ifExist(book.rentList)}}
        </span>
        <span v-else class="right badge badge-success">Available</span>
        <p> {{book.category.name}}</p>
        <p> {{book.description}}</p>
        <router-link :to="{ name: 'AdminBookDetail', params: { id: book.id } }" class="btn btn-primary btn-block btn-sm text-white" >
                      <i class="fa fa-info" aria-hidden="true"></i>
                        <span style="color: white"> Detail </span>
        </router-link>
      </div>
    </article>
    </div>
  </main>
</div>
</template>

<script>
    export default {
         data () {
            return {
                booklists: []
            }
        },
        created(){
            this.getBookList();
        },
        methods: {
          ifExist(items){
            var length = items.length;
            for(var i = 0; i < length; i++){
               if(items[i].rent_status == 'confirm'){
                  return 'In Rent';
               }else if(items[i].rent_status == 'queue'){
                  return 'In Queue';
               }else if(items[i].rent_status == 'reject'){
                  return 'Not Available';
               }else{
                  return 'Cancel';
               }
            }
          },
            getBookList: function(){
                axios.get('/_bookcafe/admin/book-list').then(response => {
                  console.log(response.data);
                  this.booklists = response.data;
                })
                .catch(error => {
                    console.log(error)
                })
            }
        }
    }
</script>

<style scoped>
.fit-image{
  text-align: center;
  width: 300px;
  height: 300px;
}
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  grid-gap: 20px;
  align-items: stretch;
}

.grid > article {
  border: 1px solid #ccc;
  box-shadow: 2px 2px 6px 0px rgba(0, 0, 0, 0.3);
}

.grid > article img {
  max-width: 100%;
}

.grid .text {
  padding: 20px;
}

</style>