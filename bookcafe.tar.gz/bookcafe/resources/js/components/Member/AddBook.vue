<template>
<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Register My Own Book</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" @submit="formSubmit" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="name">Book Name</label>
                    <input type="text" v-model="name" class="form-control" id="name" placeholder="Enter Book Name" required >
                  </div>
                    <div class="form-group ">
                        <label for="type">Which Category You Want To Store?</label>
                        <select name="category" id="" class="form-control" v-model="category" required>
                            <option v-for="(category,index) in categories" :key="index" :value="category.id">{{category.name}}</option>
                        </select>
                    </div>
                  <div class="form-group">
                    <label for="desc">Tell us For Your Opinion About This Book</label>
                    <textarea v-model="desc" id="desc" class="form-control" required></textarea>
                  </div>
                    <div class="form-group" style="margin-bottom: 100px; ">
                      <label for="exampleInputFile">Upload Book Front Cover</label>
                      <div class="input-group">
                          <div id="preview">
                              <div class="custom-file">
                                <input type="file" class="custom-file-input" id="e" @change="onPreviewFrontSelected" required>
                                <label class="custom-file-label" for="aaa" >Front Cover Upload</label>
                              </div>
                            <!-- <img v-if="image" :src="image" id="lol" /> -->
                            <img :src="front_url" id="frontCover">
                          </div>
                      </div>
                    </div>
                    <div class="form-group" style="margin-bottom:100px;">
                      <label for="exampleInputFile">Upload Book Back Cover</label>
                      <div class="input-group">
                          <div id="preview">
                              <div class="custom-file">
                                <input type="file" class="custom-file-input" id="backCoverFile" @change="onPreviewBackSelected" required>
                                <label class="custom-file-label" for="backCoverFile" >Back Cover Upload</label>
                              </div>
                                <img :src="back_url" id="backCover">
                          </div>
                      </div>
                    </div>
                  <!-- <div class="form-group ">
                    <label for="exampleInputFile">Upload Book Cover (* You can upload Multiple Images)</label>
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="multipleCover" @change="onFileSelected"  multiple>
                          <label class="custom-file-label" for="multipleCover" >Choose file</label>
                        </div>
                        <div class="input-group-append" v-if="!selectedFiles.length">
                          <span class="input-group-text" id="">No Image</span>
                        </div>
                        <div class="input-group-append" v-else>
                          <span class="input-group-text" id="" style="background: green; color: #fff">Got {{selectedFiles.length}} Files Selected</span>
                        </div>
                      </div>
                  </div> -->
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Request To Admin</button>
                </div>
              </form>
            </div>
</template>

<script>
    export default {
            data () {
            return {
                name: '',
                category: null,
                desc: '',
                front_url: '',
                front_file: null,
                back_url: '',
                back_file: null,
                selectedFiles : [],
                categories : [],
                front_img: '',
                back_img: '',
                test: null
            }
        },
        mounted(){
          this.front_img = $("#frontCover").cropme({
              container: {
                width: 600,
                height: 500
              },
              viewport: {
                width: 500,
                height: 400,
                border: {
                  enable: true,
                  width: 5,
                  color: '#f00'
                }
              }
            });
          this.back_img = $("#backCover").cropme({
              container: {
                width: 600,
                height: 500
              },
              viewport: {
                width: 500,
                height: 400,
                border: {
                  enable: true,
                  width: 5,
                  color: '#f00'
                }
              }
            });
        },
        created(){
                this.$Progress.start();
                axios.get("/_bookcafe/get")
                .then((response) => {
                    this.categories = response.data;
                    this.$Progress.finish();
                })
                .catch((error) => {
                    console.log(error);
                });
        },
        methods: {
          handle(e){
              var f = e.target.files[0];
              let reader = new FileReader();
              let that = this;
              reader.onload = function (e) {
                // that.images.push(e.target.result);
                that.image = e.target.result;
              }
              reader.readAsDataURL(f);
          },
            onFileSelected(e){
                let getFiles = e.target.files;
                if(!getFiles.length){
                    return false;
                }
                for(let i=0; i< getFiles.length; i++){
                    this.selectedFiles.push(getFiles[i]);
                }
            },
            onPreviewFrontSelected(e){
              this.front_file = e.target.files[0];
              this.front_url = URL.createObjectURL(this.front_file);

            },
            onPreviewBackSelected(e){
              this.back_file = e.target.files[0];
              this.back_url = URL.createObjectURL( this.back_file);
            },
            getSubmitForm: function(frontImg,backImg){
                const data = new FormData();
                // for(let v=0;v<this.selectedFiles.length;v++){
                //     data.append('images[]', this.selectedFiles[v],this.selectedFiles[v].name);
                // }
                const json_data = JSON.stringify({
                    name: this.name,
                    category: this.category,
                    desc: this.desc,
                });
                data.append('data',json_data);
                data.append('front_file',frontImg );
                data.append('back_file',backImg);
                axios.post('/_bookcafe/request',data)
                    .then(response => {
                    swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: response.data.message,
                            showConfirmButton: false,
                            timer: 3000
                    });
                    this.name = '';
                    this.category = '';
                    this.desc = '';
                    this.$router.push('/my-pending-list');
                    for(let a=0; a<this.selectedFiles.length; a++){
                        this.selectedFiles.splice(a, this.selectedFiles.length);
                    }
                    })
                    .catch(error => {
                        console.log(error)
                    })
            },
            formSubmit: function(e){
                e.preventDefault();
                var that = this;
                    that.front_img.cropme('crop').then( function(frontImg) {
                        that.back_img.cropme('crop').then( function(backImg) {
                           that.getSubmitForm(frontImg,backImg);
                        });
                    });
                return ;
            }
        }
    }
</script>
<style scoped>
#preview {
 background: grey;
 width: 600px;
 height: 600px;
}
</style>