<template>
    <div class="container">
        <div class="row" >
          <div class="col-12 text-center mt-5">
              This is place To Show My Rented Books
          </div>
        </div>
    </div>
</template>

<script>
    export default {
         data () {
            return {
            }
        },
        created(){
        },
        methods: {
        }
    }
</script>