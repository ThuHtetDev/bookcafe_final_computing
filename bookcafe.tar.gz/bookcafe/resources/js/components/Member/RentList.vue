<template>
    <div class="container">
        <div class="row" v-if="rentLists.length > 0">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                    My Current Rent Books List
                </h3>
                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>Book-Name</th>
                      <th>Rent Date</th>
                      <th>Request Date</th>
                      <th>Today</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(book,index) in rentLists" :key="index">
                            <td>{{book.about_book.name}}</td>
                            <td>From <b>{{book.start_date}}</b> To <b>{{book.return_date}}</b> </td>
                            <td>{{book.created_at}}</td>
                            <td>{{today}}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right">
                  <li class="page-item"><a class="page-link" href="#">«</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">»</a></li>
                </ul>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
        <div class="row" v-else>
          <div class="col-12 text-center mt-5">
              I have No Books In My Current Rent List
          </div>
        </div>
    </div>
</template>

<script>
    export default {
         data () {
            return {
                rentLists: [],
                today: null
            }
        },
        created(){
            this.getRentList();
        },
        methods: {
            getRentList: function(){
                this.$Progress.start();
                axios.get('/_bookcafe/member/rent-list').then(response => {
                   this.rentLists = response.data;
                   this.today = moment().format().substring(0, 10)
                  this.$Progress.finish();
                })
                .catch(error => {
                    console.log(error)
                })
            }
        }
    }
</script>