<template>
    <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                    My Book List
                </h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ISBN</th>
                      <th>Book-Name</th>
                      <th>Description</th>
                      <th>Category</th>
                      <th>Current Status</th>
                      <th>Your Cancel</th>
                      <th>Registerd At</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(book,index) in books" :key="index" :class="book.is_reject == '1' ? 'rejected' : ''">
                      <td>{{book.isbn}}</td>
                      <td>{{book.name}}</td>
                      <td>{{book.description.substring(0,18)+".." }}</td>
                      <td>{{book.category.name}}</td>
                      <td v-if="book.status == 'pending'">
                        <span :class="book.is_reject == '1' ?'right badge badge-danger' : 'right badge badge-warning'">
                          {{book.is_reject == '1' ? 'Rejected by admin ' : 'Pending'}}
                        </span>
                        <span v-if="book.is_cancel == '1'" class="right badge badge-danger">Cancel by Me</span>
                      </td>
                      <td v-else>
                         <span class="right badge badge-success">Published</span>
                         <span v-if="book.is_cancel == '1'" class="right badge badge-danger">Cancel by Me</span>
                      </td>
                      <td v-if="book.is_cancel == '0'">No</td>
                      <td v-else>Cancelled This Book</td>
                      <td>{{book.created_at}}</td>
                      <td>Action</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer clearfix">
                <div class="input-group-append float-left">
                    <router-link to="/add-book" class="btn btn-primary">Register New Book</router-link>
                </div>
                <ul class="pagination pagination-sm m-0 float-right">
                  <li class="page-item"><a class="page-link" href="#">«</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">»</a></li>
                </ul>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
    </div>
</template>

<script>
    export default {
         data () {
            return {
            books: [],
            }
        },
        created(){
               this.$Progress.start();
                axios.get("/_bookcafe/my-book-list")
                .then((response) => {
                    this.books = response.data;
                    this.$Progress.finish();
                })
                .catch((error) => {
                    console.log(error);
                });
        },
    }
</script>
<style scoped>
.rejected{
  background: red;
  color: #fff;
}
</style>