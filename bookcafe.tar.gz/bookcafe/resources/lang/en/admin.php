<?php

return [
    'user_management' => 'User Management',
    'member_manage' => 'Member Manage',
    'admin_manage' => 'Admin Manage',
    'category' => 'Category',
    'category_list' => 'Category List',
    'add_category' => 'Add Category',
    'book_newfeed' => 'Book NewFeeds',
    'member_book_request' => 'New Book Request',
    'rent_request' => 'Rent Request'

];