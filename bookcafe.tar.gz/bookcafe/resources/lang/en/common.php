<?php

return [

    'title' => 'BookCaFe',
    'logout' => 'Logout',
    'book_newfeed' => 'Book NewFeeds'

];
