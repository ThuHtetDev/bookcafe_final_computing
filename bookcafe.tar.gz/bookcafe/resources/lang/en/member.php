<?php

return [
    'register_book' => 'Register New Book',
    'book_newfeed' => 'Book NewFeeds',
    'my_book' => 'My Books',
    'my_pending' => 'My Pending Books',
    'my_queue' => 'My Queue Books',
    'my_current_rent' => 'My Current Rent Books',
    'my_rented_book' => 'My Rented Books',
    'setting' => 'Setting'

];