<?php

return [
    'user_management' => 'အသုံးပြုသူများ',
    'member_manage' => 'အသင်းဝင်များ',
    'admin_manage' => 'အက်မင်များ',
    'category' => 'အမျိုးအစား',
    'category_list' => 'အမျိုးအစားစာရင်း',
    'add_category' => 'အမျိုးအစားထည့်ရန်',
    'book_newfeed' => 'စာအုပ်သတင်း',
    'member_book_request' => 'စာအုပ်သစ်လျောက်ထားမှုများ',
    'rent_request' => 'အငှားစာအုပ်လျောက်ထားမှုများ'

];