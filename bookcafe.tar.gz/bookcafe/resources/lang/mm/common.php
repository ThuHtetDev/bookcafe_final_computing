<?php

return [

    'title' => 'စာအုပ်ဆိုင်',
    'logout' => 'ထွက်မည်',
    'book_newfeed' => 'စာအုပ်စာရင်း'
];
