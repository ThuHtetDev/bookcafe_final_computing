<?php $__env->startSection('content'); ?>

<div style="width: 800px; margin:0 auto;">
    <table class="table table-striped">
    <thead>
        <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Role</th>
        <th scope="col">joined_date</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($key + 1); ?></th>
            <td><?php echo e($member->name); ?></td>
            <td><?php echo e($member->email); ?></td>
            <td><?php echo e($member->type); ?></td>
            <td><?php echo e($member->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookcafe\resources\views/users/memberlist.blade.php ENDPATH**/ ?>