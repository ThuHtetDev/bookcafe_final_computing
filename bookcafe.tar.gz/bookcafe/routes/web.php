<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
})->name('login');
Route::get('/test', function () {
    return view('test');
});
Route::get('register','Auth\RegisterController@redirectToLogin');
Route::get('/home', 'HomeController@index')->name('home');
Auth::routes([
    'register' => false, // Registration Routes...
    'reset' => false, // Password Reset Routes...
    'verify' => false, // Email Verification Routes...
  ]);
  // LANGUAGE CHANGE SECTION
    Route::get('locale/{locale}', function($locale){
        Session::put('locale', $locale);
        if(\Auth::check()){
            if(\Auth::user()->lang != $locale){
                $user = \Auth::user();
                $user->lang = $locale;
                $user->save();
            }
        }
        return redirect()->back();
    })->name('locale');

  Route::group([ 'prefix' => '_bookcafe' ], function(){
        // @ Admin & SuperAdmin Permission
        Route::group([ 'middleware' => 'can:manage-administration' ], function(){
                Route::get('/memberlist','User\UserController@memberlist')->name('users.memberlist');
                Route::get('/adminlist','User\UserController@adminlist')->name('users.adminlist');
                Route::post('/member/save','User\UserController@saveMember')->name('member.save');
                Route::post('/admin/save','User\UserController@saveAdmin')->name('admin.save');
    
                Route::get('/','Admin\CategoryController@getCategory')->name('admin.getcategory');
                Route::post('/add','Admin\CategoryController@saveCategory')->name('admin.savecategory');
    
                Route::get('member/request','Book\BookController@memberBookRequest')->name('admin.bookrequest');
                Route::get('detail/{id}','Book\BookController@bookDetail')->name('admin.bookrequest-detail');

                // Publish
                Route::post('/book/publish/','Book\BookController@publishBook')->name('admin.publish');
                Route::get('/admin/book-list','Book\BookController@bookList')->name('adminpublish.booklist');
                Route::post('/book/reject/','Book\BookController@rejectBook')->name('admin.reject');

                Route::get('/admin/check-rent-request','Book\BookController@checkRentList')->name('admin.checkRentList');
                Route::get('/admin/rent-sort-detail/{id}','Book\BookController@RentListSort')->name('admin.rentListSort');
                Route::post('/admin/save-rent-request','Book\BookController@saveRent')->name('admin.saveRent');
        });

        // @ Member Permission
        Route::group([ 'middleware' => 'can:isMember' ], function(){
            Route::get('/get','Admin\CategoryController@getCategory')->name('member.getcategory');
            Route::post('/request','Book\BookController@memberSaveBook')->name('member.savebook');
            Route::get('/my-book-list','Book\BookController@memberBookList')->name('member.booklist');
            Route::get('/member/book-list','Book\BookController@bookList')->name('memberpublish.booklist');
            Route::get('/member/book/detail/{id}','Book\BookController@memberBookDetail')->name('memberpublish.bookdetail');
            Route::get('/member/pending-list','Book\BookController@memberPendingList')->name('memberpending.booklist');
            Route::post('/member/pending-list/cancel','Book\BookController@memberPendingListCancel')->name('memberpending.cancel');

            Route::post('/rent-request','Book\BookController@rentRequest')->name('member.rentRequest');
            Route::post('/change-password','User\UserController@changePassword')->name('member.changePassword');

            Route::get('/member/queue-list','Book\BookController@queueLists')->name('member.queueList');
            Route::get('/member/rent-list','Book\BookController@rentLists')->name('member.rentList');
        });
        // @ All Permission
        Route::group([ 'middleware' => 'can:manage-all' ], function(){
         
        });
    });

Route::get('/{any}', 'HomeController@index')->where('any', '^(?!api).*$');


