<?php

namespace App\Http\Controllers\Book;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Book;
use Auth;
use App\User;
use App\BookImage;
use Carbon\Carbon;
use App\RentBook;
use DB;

class BookController extends Controller
{
    // @ Save Request Book By Member
    public function memberSaveBook(Request $request){
        $datas = json_decode($request['data']);
        $front_image = str_replace('data:image/png;base64,', '', $request['front_file']);
        $front_image = str_replace(' ', '+', $front_image);
        $front_file_name = 'front_'.time().'.png';
        if($front_image!=""){
            \Storage::disk('public')->put('user_'.Auth::user()->id.'/book/front_cover/'.$front_file_name,base64_decode($front_image));
        }

        $back_image = str_replace('data:image/png;base64,', '', $request['back_file']);
        $back_image = str_replace(' ', '+', $back_image);
  
        $back_file_name = 'back_'.time().'.png';
        if($back_image!=""){
            \Storage::disk('public')->put('user_'.Auth::user()->id.'/book/back_cover/'.$back_file_name,base64_decode($back_image));
        }
        $createBook = new Book;
        $createBook->isbn = mt_rand(10000000,99999999);
        $createBook->name = $datas->name;
        $createBook->description = $datas->desc;
        $createBook->user_id = Auth::user()->id;
        $createBook->front_cover = $front_file_name;
        $createBook->back_cover = $back_file_name;
        $createBook->category_id = $datas->category;
        $createBook->save();

        // $images = $request['images'];
        // foreach($images as $image){
        //     $fileName =$image->getClientOriginalName();
        //     $fileSize = $image->getClientSize();
        //     $image->storeAs('public/user_'.Auth::user()->id.'/book/inner_images/',$fileName);

        //     $newBookImage = new BookImage;
        //     $newBookImage->img_path = $fileName;
        //     $newBookImage->book_id = $createBook->id;
        //     $newBookImage->save();
        // }
        return response()->json(['message' => 'Registered Book is successfully sent to Admin']);
    }

    // @ Get Member Book Lists
    public function memberBookList(){
        $authBookList = Book::where('user_id',Auth::user()->id)->get();
        $books = [];
        foreach($authBookList as $book){
            $book['category'] = $book->category->getAttributes();
            $books[] = $book->getAttributes();
        }
        return response()->json($books);
    }

    // @ Get Member Request Book For Admin
    public function memberBookRequest(){
        $bookRequest = Book::where('status','pending')->where('is_reject','0')->orderBy('created_at','desc')->get();
        $books = [];
        foreach($bookRequest as $book){
            $book['category'] = $book->category->getAttributes();
            $books[] = $book->getAttributes();
        }
        return response()->json($books);
    }

    // @ Get Detail Books For Admin
    public function bookDetail($id){
        $bookDetail = Book::find($id);
        if(is_null($bookDetail)){
            return response()->json(['message' => 'Page Not Found']);
        }
        $bookImages = $bookDetail->bookimages;
        $publishAdmin = null;
        if(!is_null($bookDetail->publish_user_id)){
            $publishAdmin = User::where('id',$bookDetail->publish_user_id)->first();
        }
        $output = [
            'bookDetail' => $bookDetail,
            'bookUser' => $bookDetail->user,
            'bookImages' => $bookImages,
            'bookCategory' => $bookDetail->category,
            'publishAdmin' => $publishAdmin
        ];
        return response()->json($output);
    }

    // @ Publish book By Admin
    public function publishBook(Request $request){
        $publishId = $request->id;
        $publishBook = Book::find($publishId);
        $publishBook->status = "publish";
        $publishBook->publish_user_id = Auth::user()->id;
        $publishBook->save();
        $output = [
            'success' => 'true',
            'publish_admin' => Auth::user()
        ];
        return response()->json($output);
    }

    // @ Get  Books Lists with category/rent-list
    public function bookList(){
        $bookList =  Book::where('status','publish')->where('is_reject','0')->where('is_cancel','0')->orderBy('updated_at', 'desc')->get();
        $books = [];
        foreach($bookList as $book){
            $book['category'] = $book->category->getAttributes();
            $book['rentList'] = $book->rentBooks;
            $books[] = $book->getAttributes();
        }
        return response()->json($books);
    }

    // @ Get Detail Books For Members
    public function memberBookDetail($id){
        $bookDetail = Book::find($id);
        if(is_null($bookDetail)){
            return response()->json(['message' => 'Page Not Found']);
        }
        $bookImages = $bookDetail->bookimages;
        $bookCategory =  $bookDetail->category;
        $rentLists = $bookDetail->rentBooks;
        return response()->json($bookDetail);
    }

    // @ Get Member Pending Books
    public function memberPendingList(){
        $pendingList = Book::where('status','pending')->where('user_id',Auth::user()->id)->where('is_reject','0')->where('is_cancel','0')->orderBy('created_at','desc')->get();
        return response()->json($pendingList);
    }

    // @ Cancel Pending Book By Member
    public function memberPendingListCancel(Request $request){
        $cancelBook = Book::find($request['id']);
        $cancelBook->is_cancel = '1';
        $cancelBook->save();
        return response()->json($cancelBook);
    }

    // @ Reject Book By Admin
    public function rejectBook(Request $request){
        $rejectId = $request['id'];
        $rejectBook = Book::find($rejectId);
        $rejectBook->is_reject = '1';
        $rejectBook->save();
        return response()->json(['message' => $rejectBook->name .' is rejected']);
    }

    // @ Rent Request By member
    public function rentRequest(Request $request){
        $rentRequestBook = Book::find($request['bookId']);
        $start_date = Carbon::parse($request['start_date']);
        $return_date = Carbon::parse($request['return_date']);
        $rentBook = new RentBook;
        $rentBook->user_id = Auth::user()->id;
        $rentBook->book_id = $rentRequestBook->id;
        $rentBook->start_date =  $start_date;
        $rentBook->return_date =  $return_date;
        $rentBook->save();
        return response()->json(['message' => 'Rent Request Successfully']);
    }

    // @ Rent Request View By Admin
    public function checkRentList(){
        $rentRequest = RentBook::where('rent_status','queue')->where('has_return','0')->get();
        $groupedList = $rentRequest->groupBy('book_id');
        return response()->json($groupedList);
    }

    // @ Rent Request Sort By Admin
    public function RentListSort($id){
        $rentBookList = RentBook::where('book_id',$id)->where('rent_status','queue')->where('has_return','0')->orderBy('created_at', 'desc')->get();
        $rentInfos = [];
        foreach($rentBookList as $rentBook){
            $rentBook['about_member'] = $rentBook->user;
            $rentBook['about_book'] = $rentBook->book;
            $rentInfos[] = $rentBook;
        }
        return response()->json($rentInfos);
    }

    // @ Confirm Rent Request By Admin
    public function saveRent(Request $request){
        $rentBook = RentBook::find($request['id']);
        if($request['type'] == 'confirm'){
            $rentBook->rent_status = 'confirm';
            $rentBook->save();
            $output = [
                'success' => 'confirm',
                'message' => 'Confirmation is sent'
            ];
            return response()->json($output);
        }else{
            $rentBook->rent_status = 'reject';
            $rentBook->save();
            $output = [
                'success' => 'confirm',
                'message' => 'Rejection is sent'
            ];
            return response()->json($output);
        }
    }

    // @ Member Own Queue List
    public function queueLists(){
        $authUser = Auth::user()->id;
        $MyQueueBookList = RentBook::where('user_id',$authUser)->where('rent_status','queue')->where('has_return','0')->orderBy('created_at', 'desc')->get();
        $rentInfos = [];
        foreach($MyQueueBookList as $rentBook){
            $rentBook['about_book'] = $rentBook->book;
            $rentInfos[] = $rentBook;
        }
        return response()->json($rentInfos);
    }

    // @ Member Own Rent List
    public function rentLists(){
        $authUser = Auth::user()->id;
        $MyCurrentRent = RentBook::where('user_id',$authUser)->where('rent_status','confirm')->where('has_return','0')->orderBy('created_at', 'desc')->get();
        $rentInfos = [];
        foreach($MyCurrentRent as $rentBook){
            $rentBook['about_book'] = $rentBook->book;
            $rentInfos[] = $rentBook;
        }
        return response()->json($rentInfos);
    }
}
